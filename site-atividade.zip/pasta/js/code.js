function backhome(){
    window.location.href = "index.html"
}

function page2(){
    window.location.href = "second.html"
}

function page3(){
    window.location.href = "third.html"
}

function page4(){
    window.location.href = "fourth.html"
}

function page5(){
    window.location.href = "fifth.html"
}





